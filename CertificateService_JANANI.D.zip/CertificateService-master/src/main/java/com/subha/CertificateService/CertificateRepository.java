package com.subha.CertificateService;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CertificateRepository extends JpaRepository <Certificate,Integer>
{

}
